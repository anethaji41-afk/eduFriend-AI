import React, { useState } from 'react';
import { 
  Target, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle, 
  Calendar, 
  Clock, 
  Filter,
  X
} from 'lucide-react';
import { useEdu } from '../context/EduContext';
import confetti from 'canvas-confetti';

export const GoalsPage = () => {
  const { goals, addGoal, toggleGoal, deleteGoal } = useEdu();
  const [filterSubject, setFilterSubject] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New Goal Form state
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('Machine Learning');
  const [targetMinutes, setTargetMinutes] = useState(45);
  const [priority, setPriority] = useState('Medium');

  const subjects = ['All', 'Machine Learning', 'Data Structures', 'Python', 'Web Development', 'Other'];

  const filteredGoals = goals.filter((g) => {
    if (filterSubject === 'All') return true;
    return g.subject === filterSubject;
  });

  const handleCreate = (e) => {
    e.preventDefault();
    if (!title.trim()) return;

    addGoal({
      title: title.trim(),
      subject,
      targetMinutes: Number(targetMinutes),
      priority
    });

    setTitle('');
    setIsModalOpen(false);
  };

  const handleToggle = (id) => {
    toggleGoal(id);
    const goal = goals.find((g) => g.id === id);
    if (goal && !goal.completed) {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
            <Target className="w-6 h-6 text-purple-400" />
            <span>Daily Study Goals</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Set, track, and conquer your learning milestones every day.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 hover:scale-105 active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Add Study Goal</span>
        </button>
      </div>

      {/* Subject Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {subjects.map((subj) => (
          <button
            key={subj}
            onClick={() => setFilterSubject(subj)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              filterSubject === subj
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'bg-slate-800/70 text-slate-400 hover:text-slate-200 hover:bg-slate-700/70'
            }`}
          >
            {subj}
          </button>
        ))}
      </div>

      {/* Goals List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredGoals.length === 0 ? (
          <div className="col-span-full glass-panel p-10 rounded-3xl text-center border border-white/10 text-slate-400">
            <Target className="w-12 h-12 mx-auto text-purple-400/40 mb-3" />
            <p className="text-base font-semibold text-slate-300">No study goals found in this category</p>
            <p className="text-xs text-slate-500 mt-1">Add your first target to boost today's streak!</p>
          </div>
        ) : (
          filteredGoals.map((goal) => (
            <div
              key={goal.id}
              className={`p-5 rounded-3xl border transition-all duration-200 flex flex-col justify-between ${
                goal.completed
                  ? 'bg-slate-900/30 border-white/5 opacity-70'
                  : 'glass-panel-interactive border-white/10'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-lg bg-purple-500/10 text-purple-300 border border-purple-500/20">
                    {goal.subject}
                  </span>
                  <span
                    className={`text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-full ${
                      goal.priority === 'High'
                        ? 'bg-rose-500/10 text-rose-300 border border-rose-500/20'
                        : goal.priority === 'Medium'
                        ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                        : 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                    }`}
                  >
                    {goal.priority} Priority
                  </span>
                </div>

                <h3 className={`text-base font-bold mb-2 ${goal.completed ? 'line-through text-slate-500' : 'text-slate-100'}`}>
                  {goal.title}
                </h3>
              </div>

              <div className="flex items-center justify-between pt-4 mt-2 border-t border-white/5">
                <div className="flex items-center gap-1.5 text-xs text-slate-400">
                  <Clock className="w-3.5 h-3.5 text-purple-400" />
                  <span>{goal.targetMinutes} minutes</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleToggle(goal.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      goal.completed
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-purple-600 hover:bg-purple-500 text-white'
                    }`}
                  >
                    {goal.completed ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Completed</span>
                      </>
                    ) : (
                      <>
                        <Circle className="w-3.5 h-3.5" />
                        <span>Mark Done</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => deleteGoal(goal.id)}
                    className="p-1.5 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                    title="Delete goal"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Goal Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
          <div className="relative w-full max-w-md glass-panel p-6 sm:p-7 rounded-3xl border border-purple-500/30 shadow-2xl bg-slate-900/95">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-bold text-white mb-1">Add Daily Study Goal</h3>
            <p className="text-xs text-slate-400 mb-6">Plan your focus area and time commitment</p>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Goal Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Complete Introduction to Neural Networks"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950/70 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Subject</label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full bg-slate-950/70 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="Machine Learning">Machine Learning</option>
                  <option value="Data Structures">Data Structures</option>
                  <option value="Python">Python</option>
                  <option value="Web Development">Web Development</option>
                  <option value="Mathematics">Mathematics</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">Target (Minutes)</label>
                  <input
                    type="number"
                    min="5"
                    max="300"
                    value={targetMinutes}
                    onChange={(e) => setTargetMinutes(e.target.value)}
                    className="w-full bg-slate-950/70 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value)}
                    className="w-full bg-slate-950/70 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
                  >
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
              </div>

              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm shadow-xl shadow-purple-600/30 hover:scale-[1.01] active:scale-[0.99] transition-all"
                >
                  Save Study Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
