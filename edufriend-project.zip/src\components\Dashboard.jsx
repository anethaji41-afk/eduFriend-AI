import React, { useState } from 'react';
import { 
  Sparkles, 
  Flame, 
  Clock, 
  Target, 
  BookText, 
  HelpCircle, 
  Play, 
  CheckCircle2, 
  Circle, 
  Plus, 
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import { useEdu } from '../context/EduContext';
import confetti from 'canvas-confetti';

export const Dashboard = ({ onStartQuiz, onOpenAddGoal }) => {
  const { 
    user, 
    goals, 
    toggleGoal, 
    notes, 
    quizzes, 
    sessions, 
    setActiveTab, 
    getMotivationalQuote 
  } = useEdu();

  // Compute Today's Stats
  const todayStr = new Date().toISOString().split('T')[0];
  const todaySessions = sessions.filter((s) => s.date === todayStr);
  const todayStudyMinutes = todaySessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const dailyGoalMinutes = user?.dailyGoalMinutes || 60;
  const progressPercent = Math.min(100, Math.round((todayStudyMinutes / dailyGoalMinutes) * 100));

  // Average Quiz Score
  const avgQuizScore = quizzes.length > 0
    ? Math.round(quizzes.reduce((acc, q) => acc + (q.percentage || 0), 0) / quizzes.length)
    : 0;

  const todayGoals = goals.filter((g) => g.date === todayStr || !g.completed);
  const recentNotes = notes.slice(0, 3);
  const motivation = getMotivationalQuote();

  // Dynamic greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Welcome & Motivational Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl glass-panel p-6 sm:p-8 border border-purple-500/20 shadow-2xl">
        <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-gradient-to-br from-purple-600/30 via-pink-600/20 to-cyan-500/20 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-semibold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> EduFriend Daily AI
              </span>
              <span className="text-xs text-slate-400">
                {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
              {getGreeting()}, {user?.name || 'Student'}! 👋
            </h1>
            <p className="text-purple-200/90 text-sm sm:text-base font-medium max-w-xl">
              Ready to make today's study session count?
            </p>

            {/* Dynamic AI Motivational Quote */}
            <div className="mt-4 p-3.5 rounded-2xl bg-purple-950/40 border border-purple-500/20 max-w-2xl">
              <p className="text-xs sm:text-sm italic text-purple-200">
                {motivation.quote}
              </p>
            </div>
          </div>

          {/* Quick Actions CTA */}
          <div className="flex flex-wrap md:flex-col gap-3 shrink-0">
            <button
              onClick={() => setActiveTab('timer')}
              className="flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-3 rounded-2xl font-bold text-sm bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-600/30 hover:scale-105 active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Start Timer</span>
            </button>
            <button
              onClick={() => setActiveTab('notes')}
              className="flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-3 rounded-2xl font-bold text-sm bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 border border-white/10 hover:border-purple-500/40 transition-all"
            >
              <BookText className="w-4 h-4 text-purple-400" />
              <span>View Notes</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Today's Study Time */}
        <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Today's Study</span>
            <span className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-extrabold text-white">
            {todayStudyMinutes} <span className="text-xs font-normal text-slate-400">min</span>
          </div>
          <div className="mt-2 text-xs text-purple-300">
            Goal: {dailyGoalMinutes} min
          </div>
        </div>

        {/* Daily Goal Progress */}
        <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Goal Progress</span>
            <span className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
              <Target className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-extrabold text-white">
            {progressPercent}%
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-purple-500 to-cyan-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Current Streak */}
        <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Current Streak</span>
            <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <Flame className="w-4 h-4 fill-amber-400" />
            </span>
          </div>
          <div className="text-2xl font-extrabold text-amber-400 flex items-center gap-1">
            {user?.streak || 0} <span className="text-xs font-semibold text-slate-400">Days 🔥</span>
          </div>
          <div className="mt-2 text-xs text-slate-400">
            Best: {user?.bestStreak || 14} days
          </div>
        </div>

        {/* Quiz Score Avg */}
        <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Quiz Average</span>
            <span className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <HelpCircle className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-extrabold text-cyan-300">
            {avgQuizScore}%
          </div>
          <div className="mt-2 text-xs text-slate-400">
            {quizzes.length} quizzes completed
          </div>
        </div>

        {/* Notes Created */}
        <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Notes Created</span>
            <span className="p-2 rounded-xl bg-pink-500/10 text-pink-400">
              <BookText className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-extrabold text-white">
            {notes.length}
          </div>
          <div className="mt-2 text-xs text-pink-300">
            Ready for AI Quizzes
          </div>
        </div>
      </div>

      {/* Main Content Grid: Daily Goals & Recent Study Notes */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Today's Goals Section (7 cols) */}
        <div className="lg:col-span-7 glass-panel p-6 sm:p-7 rounded-3xl border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-400" />
              <h3 className="text-lg font-bold text-white">Daily Study Goals</h3>
            </div>
            <button
              onClick={() => setActiveTab('goals')}
              className="text-xs text-purple-400 hover:text-purple-300 font-semibold flex items-center gap-1"
            >
              <span>Manage all</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 pt-2">
            {todayGoals.length === 0 ? (
              <div className="p-6 text-center text-slate-400 bg-slate-900/50 rounded-2xl border border-white/5">
                <p className="text-sm">No pending goals for today!</p>
                <button
                  onClick={() => setActiveTab('goals')}
                  className="mt-3 inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-purple-600 text-white text-xs font-semibold"
                >
                  <Plus className="w-3.5 h-3.5" /> Add New Goal
                </button>
              </div>
            ) : (
              todayGoals.slice(0, 4).map((goal) => (
                <div
                  key={goal.id}
                  onClick={() => toggleGoal(goal.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all duration-200 flex items-center justify-between gap-4 ${
                    goal.completed
                      ? 'bg-slate-900/40 border-white/5 opacity-60'
                      : 'glass-panel-interactive border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      className="shrink-0 text-purple-400 transition-transform active:scale-90"
                    >
                      {goal.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-500/20" />
                      ) : (
                        <Circle className="w-5 h-5 text-slate-400 hover:text-purple-400" />
                      )}
                    </button>
                    <div className="min-w-0">
                      <p className={`text-sm font-semibold truncate ${goal.completed ? 'line-through text-slate-400' : 'text-slate-200'}`}>
                        {goal.title}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[11px] px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-300 font-medium border border-purple-500/20">
                          {goal.subject}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          ⏱ {goal.targetMinutes} min
                        </span>
                      </div>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-full shrink-0 ${
                      goal.priority === 'High'
                        ? 'bg-rose-500/10 text-rose-300 border border-rose-500/20'
                        : goal.priority === 'Medium'
                        ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                        : 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                    }`}
                  >
                    {goal.priority}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Study Notes & AI Quiz Launcher (5 cols) */}
        <div className="lg:col-span-5 glass-panel p-6 sm:p-7 rounded-3xl border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookText className="w-5 h-5 text-cyan-400" />
              <h3 className="text-lg font-bold text-white">Recent Notes</h3>
            </div>
            <button
              onClick={() => setActiveTab('notes')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
            >
              <span>All Notes</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 pt-2">
            {recentNotes.map((note) => (
              <div
                key={note.id}
                className="p-4 rounded-2xl glass-panel-interactive border-white/10 relative group"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                      {note.subject}
                    </span>
                    <h4 className="text-sm font-bold text-slate-100 mt-1 truncate max-w-[200px]">
                      {note.title}
                    </h4>
                  </div>

                  <button
                    onClick={() => onStartQuiz(note)}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-purple-600/20 transition-all hover:scale-105 active:scale-95 shrink-0"
                    title="Generate AI Quiz from this note"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>AI Quiz</span>
                  </button>
                </div>
                <p className="text-xs text-slate-400 line-clamp-2 mt-2">
                  {note.content}
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
