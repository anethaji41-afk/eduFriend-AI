import React, { useState } from 'react';
import { 
  Sparkles, 
  Loader2, 
  BookOpen, 
  Sliders, 
  HelpCircle,
  X,
  AlertCircle
} from 'lucide-react';
import { generateQuizFromNote } from '../services/aiQuizService';
import { useEdu } from '../context/EduContext';

export const QuizGeneratorModal = ({ note, isOpen, onClose, onQuizGenerated }) => {
  const { apiKey } = useEdu();
  const [questionCount, setQuestionCount] = useState(5);
  const [difficulty, setDifficulty] = useState('Medium');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen || !note) return null;

  const handleGenerate = async () => {
    if (!note.content || note.content.trim().length < 30) {
      setError('Please add more content to your study note before generating a quiz.');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const generatedQuestions = await generateQuizFromNote({
        noteContent: note.content,
        noteTitle: note.title,
        subject: note.subject,
        questionCount: Number(questionCount),
        difficulty,
        apiKey
      });

      if (!generatedQuestions || generatedQuestions.length === 0) {
        throw new Error('Could not parse questions from notes');
      }

      onQuizGenerated({
        noteId: note.id,
        title: `${note.subject}: ${note.title}`,
        subject: note.subject,
        difficulty,
        questionCount: generatedQuestions.length,
        questions: generatedQuestions
      });

      onClose();
    } catch (err) {
      console.error(err);
      setError('Quiz generation failed. Please try again with longer note notes.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
      <div className="relative w-full max-w-lg glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/30 shadow-2xl bg-slate-900/95 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          disabled={loading}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-white/5 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 via-pink-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-purple-600/30">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">AI Quiz Generator</h3>
            <p className="text-xs text-purple-300">Creates tailored questions strictly from your study note</p>
          </div>
        </div>

        {/* Source Note Info */}
        <div className="p-4 rounded-2xl bg-slate-950/60 border border-white/5 mb-6">
          <span className="text-[11px] font-bold uppercase tracking-wider text-purple-400">Target Note</span>
          <h4 className="text-sm font-semibold text-slate-200 truncate mt-0.5">{note.title}</h4>
          <span className="inline-block mt-2 px-2.5 py-0.5 rounded-md bg-purple-500/10 text-purple-300 border border-purple-500/20 text-xs">
            {note.subject}
          </span>
        </div>

        {error && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs mb-5">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Configurations */}
        <div className="space-y-4 mb-6">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              Number of Questions ({questionCount})
            </label>
            <div className="flex gap-2">
              {[3, 5, 8, 10].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setQuestionCount(num)}
                  disabled={loading}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                    questionCount === num
                      ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                      : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700/80'
                  }`}
                >
                  {num} Questions
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">Difficulty Level</label>
            <div className="grid grid-cols-3 gap-2">
              {['Easy', 'Medium', 'Hard'].map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setDifficulty(lvl)}
                  disabled={loading}
                  className={`py-2 rounded-xl text-xs font-bold transition-all ${
                    difficulty === lvl
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                      : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700/80'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Loading Indicator or Action */}
        {loading ? (
          <div className="flex flex-col items-center justify-center p-6 bg-purple-950/20 border border-purple-500/20 rounded-2xl text-center space-y-3">
            <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
            <div className="text-sm font-semibold text-purple-200">
              EduFriend AI is creating your quiz... 🤖
            </div>
            <p className="text-xs text-slate-400 max-w-xs">
              Analyzing key definitions, facts, and creating multiple-choice questions from "{note.title}"
            </p>
          </div>
        ) : (
          <button
            onClick={handleGenerate}
            className="w-full py-3.5 rounded-2xl font-bold text-sm bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 text-white shadow-xl shadow-purple-600/30 hover:opacity-95 transition-all flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99]"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate & Start Quiz</span>
          </button>
        )}
      </div>
    </div>
  );
};
