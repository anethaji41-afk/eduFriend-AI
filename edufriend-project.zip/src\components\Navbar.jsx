import React, { useState } from 'react';
import { 
  Sparkles, 
  Palette, 
  Video, 
  Moon, 
  Sun, 
  Layers, 
  Eye, 
  Flame, 
  Target, 
  Timer, 
  BookText, 
  History, 
  BarChart3, 
  User, 
  Menu, 
  X,
  Tv
} from 'lucide-react';
import { useEdu, COLOR_PALETTES, STUDY_VIDEOS } from '../context/EduContext';

export const Navbar = ({ onOpenAuth }) => {
  const { 
    user, 
    activeTab, 
    setActiveTab, 
    visualMode, 
    changeVisualMode, 
    themeMode, 
    changeThemeMode, 
    colorPalette, 
    changeColorPalette,
    videoTheme,
    changeVideoTheme
  } = useEdu();

  const [mobileOpen, setMobileOpen] = useState(false);
  const [themeDropdownOpen, setThemeDropdownOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Target },
    { id: 'goals', label: 'Goals', icon: Target },
    { id: 'timer', label: 'Study Timer', icon: Timer },
    { id: 'notes', label: 'Notes', icon: BookText },
    { id: 'quizzes', label: 'Quiz History', icon: History },
    { id: 'streak', label: 'Streak', icon: Flame },
    { id: 'progress', label: 'Analytics', icon: BarChart3 },
    { id: 'profile', label: 'Profile', icon: User }
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-slate-950/75 border-b border-white/10 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand Logo */}
          <div 
            onClick={() => setActiveTab('dashboard')} 
            className="flex items-center gap-3 cursor-pointer group shrink-0"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-400 p-[2px] transition-transform group-hover:scale-105 duration-200">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <span className="text-xl">🎓</span>
              </div>
            </div>
            <div>
              <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
                EduFriend
              </span>
              <span className="hidden sm:inline-block ml-2 text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 font-semibold">
                AI Companion
              </span>
            </div>
          </div>

          {/* Desktop Nav Items */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-200 ${
                    isActive
                      ? 'bg-gradient-to-r from-purple-600/35 to-indigo-600/35 text-purple-300 border border-purple-500/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-purple-400' : 'text-slate-400'}`} />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right Controls: Visual Mode Selector, Color Palette & Profile */}
          <div className="hidden sm:flex items-center gap-3">
            
            {/* Visual Mode Selector Popover / Button */}
            <div className="relative">
              <button
                onClick={() => setThemeDropdownOpen(!themeDropdownOpen)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-white/10 hover:border-purple-500/40 text-xs font-semibold text-slate-300 transition-all hover:scale-105"
                title="Visual Modes & Color Palettes"
              >
                <Palette className="w-3.5 h-3.5 text-purple-400" />
                <span className="capitalize">{visualMode}</span>
              </button>

              {/* Theme & Visual Mode Dropdown */}
              {themeDropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-72 glass-panel p-4 rounded-2xl border border-purple-500/30 shadow-2xl bg-slate-900/95 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onMouseLeave={() => setThemeDropdownOpen(false)}
                >
                  {/* 1. Visual Modes */}
                  <div className="mb-3">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                      Visual Background Mode
                    </span>
                    <div className="grid grid-cols-3 gap-1.5">
                      {[
                        { id: 'animated', label: 'Animated', icon: Sparkles },
                        { id: 'video', label: 'Video', icon: Video },
                        { id: 'minimal', label: 'Focus', icon: Eye }
                      ].map((m) => {
                        const Icon = m.icon;
                        return (
                          <button
                            key={m.id}
                            onClick={() => changeVisualMode(m.id)}
                            className={`flex flex-col items-center gap-1 p-2 rounded-xl text-[11px] font-semibold transition-all ${
                              visualMode === m.id
                                ? 'bg-purple-600 text-white shadow-md'
                                : 'bg-slate-800/80 text-slate-400 hover:text-white'
                            }`}
                          >
                            <Icon className="w-3.5 h-3.5" />
                            {m.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 2. Color Palette Family */}
                  <div className="mb-3 pt-2 border-t border-white/10">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                      Color Palette Family
                    </span>
                    <div className="grid grid-cols-2 gap-1.5">
                      {Object.keys(COLOR_PALETTES).map((pKey) => {
                        const pal = COLOR_PALETTES[pKey];
                        return (
                          <button
                            key={pKey}
                            onClick={() => changeColorPalette(pKey)}
                            className={`flex items-center gap-2 p-1.5 px-2 rounded-xl text-[11px] font-medium transition-all ${
                              colorPalette === pKey
                                ? 'bg-slate-800 text-white border border-purple-500/50'
                                : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
                            }`}
                          >
                            <span 
                              className="w-3.5 h-3.5 rounded-full shrink-0" 
                              style={{ backgroundColor: pal.accent }} 
                            />
                            <span className="truncate">{pal.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 3. If Video mode active, allow choosing study video */}
                  {visualMode === 'video' && (
                    <div className="mb-3 pt-2 border-t border-white/10">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                        Study Video Scene
                      </span>
                      <div className="space-y-1">
                        {Object.keys(STUDY_VIDEOS).map((vKey) => {
                          const v = STUDY_VIDEOS[vKey];
                          return (
                            <button
                              key={vKey}
                              onClick={() => changeVideoTheme(vKey)}
                              className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs flex items-center justify-between ${
                                videoTheme === vKey
                                  ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40 font-bold'
                                  : 'text-slate-400 hover:bg-slate-800/60'
                              }`}
                            >
                              <span>{v.name}</span>
                              <Tv className="w-3 h-3 text-purple-400" />
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* 4. Display Theme (Dark / Light / Lofi) */}
                  <div className="pt-2 border-t border-white/10">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                      Display Theme
                    </span>
                    <div className="grid grid-cols-3 gap-1.5">
                      {[
                        { id: 'dark', label: 'Dark', icon: Moon },
                        { id: 'light', label: 'Light', icon: Sun },
                        { id: 'lofi', label: 'Lofi', icon: Layers }
                      ].map((t) => {
                        const Icon = t.icon;
                        return (
                          <button
                            key={t.id}
                            onClick={() => changeThemeMode(t.id)}
                            className={`flex items-center justify-center gap-1 py-1 rounded-xl text-[11px] font-semibold transition-all ${
                              themeMode === t.id
                                ? 'bg-indigo-600 text-white'
                                : 'bg-slate-800/80 text-slate-400 hover:text-white'
                            }`}
                          >
                            <Icon className="w-3 h-3" />
                            {t.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Streak Badge */}
            <button 
              onClick={() => setActiveTab('streak')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20 transition-all text-xs font-bold"
            >
              <Flame className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span>{user?.streak || 0}d</span>
            </button>

            {/* Profile Avatar button */}
            <button
              onClick={() => setActiveTab('profile')}
              className="flex items-center gap-2 pl-2 pr-3 py-1 rounded-full bg-slate-800/80 border border-white/10 hover:border-purple-500/50 transition-all text-xs text-slate-200"
            >
              <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-purple-500 to-cyan-500 flex items-center justify-center text-xs">
                {user?.avatar || '🎓'}
              </div>
              <span className="font-medium max-w-[90px] truncate">{user?.name || 'Student'}</span>
            </button>
          </div>

          {/* Mobile hamburger menu toggle */}
          <div className="lg:hidden flex items-center gap-2">
            <button
              onClick={() => changeVisualMode(visualMode === 'animated' ? 'video' : visualMode === 'video' ? 'minimal' : 'animated')}
              className="p-2 rounded-xl bg-slate-800/80 border border-white/10 text-purple-300 text-xs"
              title="Toggle Visual Mode"
            >
              <Palette className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="p-2 rounded-xl bg-slate-800/80 border border-white/10 text-slate-300"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="lg:hidden px-4 pt-2 pb-6 bg-slate-950/95 border-b border-purple-500/20 backdrop-blur-2xl">
          <div className="grid grid-cols-2 gap-2 mt-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileOpen(false);
                  }}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-medium ${
                    isActive
                      ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40'
                      : 'text-slate-300 bg-slate-900/50 hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4 text-purple-400" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
