import React from 'react';
import { 
  BarChart3, 
  Clock, 
  Award, 
  HelpCircle, 
  TrendingUp, 
  CheckCircle,
  Flame
} from 'lucide-react';
import { useEdu } from '../context/EduContext';

export const ProgressPage = () => {
  const { sessions, goals, quizzes, user } = useEdu();

  // Weekly study data for Mon-Sun
  const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const weeklyData = [
    { day: 'Mon', minutes: 45 },
    { day: 'Tue', minutes: 60 },
    { day: 'Wed', minutes: 30 },
    { day: 'Thu', minutes: 75 },
    { day: 'Fri', minutes: 50 },
    { day: 'Sat', minutes: 65 },
    { day: 'Sun', minutes: 40 }
  ];

  const maxMinutes = Math.max(...weeklyData.map(d => d.minutes), 80);
  const totalWeeklyMinutes = weeklyData.reduce((acc, d) => acc + d.minutes, 0);
  const totalHours = ((user?.totalStudyMinutes || 480) / 60).toFixed(1);
  const completedGoalsCount = goals.filter(g => g.completed).length;

  const avgQuizScore = quizzes.length > 0
    ? Math.round(quizzes.reduce((acc, q) => acc + (q.percentage || 0), 0) / quizzes.length)
    : 0;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-indigo-400" />
          <span>Progress & Learning Analytics</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-400">
          Visualize your study consistency, weekly hours, and quiz mastery over time.
        </p>
      </div>

      {/* Top Stat Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-panel p-5 rounded-2xl border border-white/10">
          <span className="text-xs text-slate-400 font-semibold">Total Study Hours</span>
          <div className="text-2xl font-black text-white mt-1">{totalHours} <span className="text-xs font-normal text-slate-400">hrs</span></div>
          <span className="text-[11px] text-purple-400 font-medium">All sessions recorded</span>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-white/10">
          <span className="text-xs text-slate-400 font-semibold">Weekly Study Time</span>
          <div className="text-2xl font-black text-indigo-400 mt-1">{totalWeeklyMinutes} <span className="text-xs font-normal text-slate-400">mins</span></div>
          <span className="text-[11px] text-emerald-400 font-medium">↑ 18% vs previous week</span>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-white/10">
          <span className="text-xs text-slate-400 font-semibold">Goals Completed</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">{completedGoalsCount} / {goals.length}</div>
          <span className="text-[11px] text-slate-400 font-medium">Active daily milestones</span>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-white/10">
          <span className="text-xs text-slate-400 font-semibold">Average Quiz Score</span>
          <div className="text-2xl font-black text-cyan-400 mt-1">{avgQuizScore}%</div>
          <span className="text-[11px] text-cyan-300 font-medium">Across {quizzes.length} quizzes</span>
        </div>
      </div>

      {/* Weekly Study Time Bar Chart */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-white">Weekly Study Time</h3>
            <p className="text-xs text-slate-400">Daily focus minutes (Current Week)</p>
          </div>
          <span className="text-xs font-bold text-indigo-400 bg-indigo-500/10 px-3 py-1 rounded-full border border-indigo-500/20">
            Target: 60m / day
          </span>
        </div>

        {/* CSS/SVG Bar Chart */}
        <div className="pt-6 pb-2">
          <div className="h-52 flex items-end justify-between gap-2 sm:gap-4 px-2">
            {weeklyData.map((item, idx) => {
              const heightPercent = (item.minutes / maxMinutes) * 100;
              const isHigh = item.minutes >= 60;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-2 group">
                  <span className="text-[11px] font-bold text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity">
                    {item.minutes}m
                  </span>
                  <div className="w-full max-w-[48px] bg-slate-800/80 rounded-2xl p-1 flex items-end h-40">
                    <div
                      className={`w-full rounded-xl transition-all duration-700 ease-out ${
                        isHigh
                          ? 'bg-gradient-to-t from-purple-600 via-indigo-500 to-cyan-400 shadow-lg shadow-purple-600/30'
                          : 'bg-slate-700 hover:bg-slate-600'
                      }`}
                      style={{ height: `${heightPercent}%` }}
                    />
                  </div>
                  <span className="text-xs font-bold text-slate-400 mt-1">{item.day}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Subject Distribution & Performance Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass-panel p-6 rounded-3xl border border-white/10 space-y-4">
          <h3 className="text-base font-bold text-white">Subject Time Breakdown</h3>
          <div className="space-y-3">
            {[
              { subject: 'Machine Learning', percent: 45, color: 'bg-purple-500' },
              { subject: 'Data Structures', percent: 30, color: 'bg-cyan-500' },
              { subject: 'Python', percent: 25, color: 'bg-pink-500' }
            ].map((sub, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-300">{sub.subject}</span>
                  <span className="text-slate-400">{sub.percent}%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className={`${sub.color} h-full rounded-full`} style={{ width: `${sub.percent}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-panel p-6 rounded-3xl border border-white/10 space-y-4">
          <h3 className="text-base font-bold text-white">Study Habit Insights</h3>
          <div className="space-y-3 text-xs text-slate-300">
            <div className="p-3 rounded-2xl bg-slate-900/60 border border-white/5 flex items-center gap-3">
              <span className="text-2xl">⏰</span>
              <div>
                <strong className="block text-white font-semibold">Peak Productivity Hour</strong>
                <span>Most focused sessions happen between 6:00 PM – 9:00 PM.</span>
              </div>
            </div>
            <div className="p-3 rounded-2xl bg-slate-900/60 border border-white/5 flex items-center gap-3">
              <span className="text-2xl">💡</span>
              <div>
                <strong className="block text-white font-semibold">Quiz Retention Rate</strong>
                <span>Taking quizzes immediately after notes increases retention by 73%.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
