import React, { useState } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  ArrowLeft, 
  RotateCcw, 
  Trophy, 
  Sparkles,
  HelpCircle,
  Home
} from 'lucide-react';
import { useEdu } from '../context/EduContext';
import confetti from 'canvas-confetti';

export const QuizPlayer = ({ quiz, onFinish, onBack }) => {
  const { saveQuizResult, showToast } = useEdu();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [scoreData, setScoreData] = useState(null);

  const questions = quiz?.questions || [];
  const currentQ = questions[currentIndex];

  const handleSelectOption = (option) => {
    if (isSubmitted) return;
    setSelectedAnswers({
      ...selectedAnswers,
      [currentIndex]: option
    });
  };

  const handleSubmit = () => {
    let score = 0;
    const answeredQuestions = questions.map((q, idx) => {
      const selected = selectedAnswers[idx] || null;
      const isCorrect = selected === q.answer;
      if (isCorrect) score += 1;
      return {
        ...q,
        selectedAnswer: selected,
        isCorrect
      };
    });

    const percentage = Math.round((score / questions.length) * 100);
    const result = {
      noteId: quiz.noteId,
      title: quiz.title,
      subject: quiz.subject,
      difficulty: quiz.difficulty,
      questionCount: questions.length,
      score,
      percentage,
      questions: answeredQuestions
    };

    saveQuizResult(result);
    setScoreData(result);
    setIsSubmitted(true);

    if (percentage >= 70) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      showToast(`Quiz Completed! You scored ${score}/${questions.length} (${percentage}%)! 🌟`, 'streak');
    } else {
      showToast(`Quiz finished with ${percentage}%. Great practice!`, 'info');
    }
  };

  const handleRetry = () => {
    setSelectedAnswers({});
    setIsSubmitted(false);
    setScoreData(null);
    setCurrentIndex(0);
  };

  if (!quiz || questions.length === 0) {
    return (
      <div className="p-8 text-center glass-panel rounded-3xl">
        <p className="text-slate-300">No quiz questions loaded.</p>
        <button onClick={onBack} className="mt-4 px-4 py-2 bg-purple-600 rounded-xl text-white">
          Back
        </button>
      </div>
    );
  }

  // Result Summary View
  if (isSubmitted && scoreData) {
    return (
      <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in zoom-in-95 duration-300">
        <div className="glass-panel p-8 rounded-3xl text-center relative overflow-hidden border border-purple-500/30 shadow-2xl">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-purple-600 via-amber-500 to-pink-500 p-[2px] mb-4">
            <div className="w-full h-full bg-slate-950 rounded-[22px] flex items-center justify-center text-4xl">
              <Trophy className="w-10 h-10 text-amber-400" />
            </div>
          </div>

          <h2 className="text-3xl font-extrabold text-white mb-1">Quiz Completed! 🎉</h2>
          <p className="text-slate-400 text-sm">{scoreData.title}</p>

          <div className="my-6 inline-flex items-center gap-6 px-6 py-3 rounded-2xl bg-slate-900/80 border border-white/10">
            <div>
              <span className="text-xs text-slate-400 block uppercase font-bold tracking-wider">Your Score</span>
              <span className="text-2xl font-black text-purple-300">
                {scoreData.score} / {scoreData.questionCount}
              </span>
            </div>
            <div className="w-[1px] h-8 bg-white/10" />
            <div>
              <span className="text-xs text-slate-400 block uppercase font-bold tracking-wider">Percentage</span>
              <span className={`text-2xl font-black ${scoreData.percentage >= 70 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {scoreData.percentage}%
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleRetry}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry Quiz</span>
            </button>
            <button
              onClick={onFinish}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-sm font-bold shadow-lg shadow-purple-600/30 hover:opacity-95 transition-all"
            >
              <Home className="w-4 h-4" />
              <span>Back to Dashboard</span>
            </button>
          </div>
        </div>

        {/* Detailed Review of Answers */}
        <div className="glass-panel p-6 rounded-3xl border border-white/10 space-y-4">
          <h3 className="text-base font-bold text-slate-200">Question Review</h3>
          <div className="space-y-4">
            {scoreData.questions.map((q, idx) => {
              const isCorrect = q.selectedAnswer === q.answer;
              return (
                <div 
                  key={idx} 
                  className={`p-4 rounded-2xl border ${
                    isCorrect 
                      ? 'bg-emerald-950/20 border-emerald-500/30' 
                      : 'bg-rose-950/20 border-rose-500/30'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-xs font-bold text-slate-400">Question {idx + 1}</span>
                    {isCorrect ? (
                      <span className="flex items-center gap-1 text-xs font-bold text-emerald-400">
                        <CheckCircle2 className="w-4 h-4" /> Correct
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-xs font-bold text-rose-400">
                        <XCircle className="w-4 h-4" /> Incorrect
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-semibold text-slate-200 mb-3">{q.question}</p>
                  <div className="space-y-1.5 text-xs">
                    <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                      <span className="font-bold mr-1">Correct Answer:</span> {q.answer}
                    </div>
                    {!isCorrect && (
                      <div className="p-2 rounded-lg bg-rose-500/10 text-rose-300 border border-rose-500/20">
                        <span className="font-bold mr-1">Your Answer:</span> {q.selectedAnswer || 'Not answered'}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Active Quiz Playing View
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Quiz Header with Progress */}
      <div className="glass-panel p-5 rounded-3xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold border border-purple-500/30">
            {quiz.subject} • {quiz.difficulty}
          </span>
          <h2 className="text-lg font-bold text-white mt-1 truncate max-w-md">{quiz.title}</h2>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-purple-300">
            Question {currentIndex + 1} of {questions.length}
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden">
        <div
          className="bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 h-full transition-all duration-300"
          style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
        />
      </div>

      {/* Question Card */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/20 shadow-2xl relative">
        <div className="mb-6">
          <span className="text-xs font-semibold uppercase tracking-wider text-purple-400 block mb-2">
            Question {currentIndex + 1}
          </span>
          <h3 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
            {currentQ.question}
          </h3>
        </div>

        {/* Multiple Choice Options */}
        <div className="space-y-3">
          {currentQ.options.map((opt, oIdx) => {
            const isSelected = selectedAnswers[currentIndex] === opt;
            const letter = String.fromCharCode(65 + oIdx);
            return (
              <button
                key={oIdx}
                type="button"
                onClick={() => handleSelectOption(opt)}
                className={`w-full text-left p-4 rounded-2xl flex items-center gap-4 transition-all duration-200 border ${
                  isSelected
                    ? 'bg-purple-600/30 border-purple-400 text-white shadow-lg shadow-purple-600/20 scale-[1.01]'
                    : 'bg-slate-900/60 border-white/10 text-slate-300 hover:border-purple-500/40 hover:bg-slate-800/60'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                    isSelected
                      ? 'bg-purple-500 text-white'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {letter}
                </div>
                <span className="text-sm font-medium flex-1">{opt}</span>
              </button>
            );
          })}
        </div>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-white/10">
          <button
            onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
            disabled={currentIndex === 0}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200 disabled:opacity-30 disabled:pointer-events-none transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          {currentIndex < questions.length - 1 ? (
            <button
              onClick={() => setCurrentIndex((prev) => Math.min(questions.length - 1, prev + 1))}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-md shadow-purple-600/30 hover:scale-105 active:scale-95"
            >
              <span>Next</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs transition-all shadow-lg shadow-emerald-500/25 hover:scale-105 active:scale-95"
            >
              <Sparkles className="w-4 h-4" />
              <span>Submit Quiz</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
