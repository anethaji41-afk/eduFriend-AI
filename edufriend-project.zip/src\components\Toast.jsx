import React from 'react';
import { 
  Sparkles, 
  Flame, 
  BookOpen, 
  CheckCircle2, 
  Info, 
  AlertCircle,
  X
} from 'lucide-react';
import { useEdu } from '../context/EduContext';

export const Toast = () => {
  const { toast } = useEdu();

  if (!toast) return null;

  const icons = {
    success: <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />,
    streak: <Flame className="w-5 h-5 text-amber-400 shrink-0 animate-bounce" />,
    error: <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />,
    info: <Sparkles className="w-5 h-5 text-cyan-400 shrink-0" />
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-md animate-bounce-short">
      <div className="flex items-center gap-3 px-4 py-3 rounded-2xl glass-panel border border-purple-500/30 shadow-2xl backdrop-blur-xl bg-slate-900/90 text-slate-100">
        {icons[toast.type] || icons.info}
        <p className="text-sm font-medium">{toast.message}</p>
      </div>
    </div>
  );
};
