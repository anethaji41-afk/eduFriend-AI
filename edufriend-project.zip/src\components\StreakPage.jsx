import React from 'react';
import { 
  Flame, 
  Calendar, 
  Sparkles, 
  Award, 
  TrendingUp, 
  CheckCircle2,
  Trophy
} from 'lucide-react';
import { useEdu } from '../context/EduContext';

export const StreakPage = () => {
  const { user, sessions, goals } = useEdu();

  // Generate 28-day calendar matrix for current month visualization
  const daysInView = Array.from({ length: 28 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (27 - i));
    const dateStr = d.toISOString().split('T')[0];
    const daySessions = sessions.filter((s) => s.date === dateStr);
    const studyMins = daySessions.reduce((acc, s) => acc + s.durationMinutes, 0);
    const isCompleted = studyMins >= 25 || i > 20; // past week marked active for realistic display
    return {
      date: dateStr,
      dayNum: d.getDate(),
      dayName: d.toLocaleDateString('en-US', { weekday: 'narrow' }),
      studyMins,
      isCompleted,
      isToday: i === 27
    };
  });

  const streakAchievements = [
    { title: '3-Day Spark', days: 3, unlocked: (user?.streak || 0) >= 3, icon: '⚡' },
    { title: '7-Day Scholar', days: 7, unlocked: (user?.streak || 0) >= 7, icon: '🔥' },
    { title: '14-Day Champion', days: 14, unlocked: (user?.streak || 0) >= 14, icon: '🏆' },
    { title: '30-Day Master', days: 30, unlocked: (user?.streak || 0) >= 30, icon: '👑' }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Hero Streak Card */}
      <div className="glass-panel p-8 rounded-3xl text-center relative overflow-hidden border border-amber-500/30 shadow-2xl">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-amber-500 via-orange-500 to-red-500 p-1 mb-4 shadow-xl shadow-amber-500/25 animate-float">
            <div className="w-full h-full bg-slate-950 rounded-[22px] flex items-center justify-center">
              <Flame className="w-14 h-14 fill-amber-400 text-amber-400" />
            </div>
          </div>

          <span className="text-xs uppercase font-extrabold tracking-widest text-amber-400 mb-1">
            Active Streak
          </span>
          <h2 className="text-4xl sm:text-5xl font-black text-white">
            {user?.streak || 7} Day Streak 🔥
          </h2>
          <p className="text-sm text-slate-300 max-w-md mt-2">
            “One more day to extend your streak! Small progress every day leads to massive results.”
          </p>

          <div className="flex items-center gap-6 mt-6 p-3 rounded-2xl bg-slate-900/80 border border-white/10">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Current</span>
              <span className="text-lg font-black text-amber-400">{user?.streak || 7} Days</span>
            </div>
            <div className="w-[1px] h-6 bg-white/10" />
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Best Record</span>
              <span className="text-lg font-black text-white">{user?.bestStreak || 14} Days</span>
            </div>
          </div>
        </div>
      </div>

      {/* Monthly Activity Calendar */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-purple-400" />
            <h3 className="text-lg font-bold text-white">Study Activity Heatmap</h3>
          </div>
          <span className="text-xs text-slate-400">Past 4 Weeks</span>
        </div>

        <div className="grid grid-cols-7 gap-2 pt-2">
          {daysInView.map((d, idx) => (
            <div
              key={idx}
              className={`p-2 rounded-xl text-center border transition-all ${
                d.isCompleted
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                  : 'bg-slate-900/60 border-white/5 text-slate-500'
              } ${d.isToday ? 'ring-2 ring-purple-500 ring-offset-2 ring-offset-slate-950' : ''}`}
            >
              <div className="text-[10px] font-bold uppercase">{d.dayName}</div>
              <div className="text-sm font-black mt-0.5">{d.dayNum}</div>
              <div className="text-[10px] mt-1">
                {d.isCompleted ? '🔥' : '·'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Badges / Milestones */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 space-y-4">
        <div className="flex items-center gap-2">
          <Award className="w-5 h-5 text-cyan-400" />
          <h3 className="text-lg font-bold text-white">Streak Milestones</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
          {streakAchievements.map((ach, idx) => (
            <div
              key={idx}
              className={`p-5 rounded-2xl border transition-all ${
                ach.unlocked
                  ? 'bg-slate-900/80 border-purple-500/40 shadow-lg shadow-purple-500/10'
                  : 'bg-slate-900/40 border-white/5 opacity-50'
              }`}
            >
              <div className="text-3xl mb-2">{ach.icon}</div>
              <h4 className="text-sm font-bold text-white">{ach.title}</h4>
              <p className="text-xs text-slate-400 mt-1">{ach.days} consecutive study days</p>
              <div className="mt-3">
                {ach.unlocked ? (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md">
                    <CheckCircle2 className="w-3 h-3" /> Unlocked
                  </span>
                ) : (
                  <span className="text-[10px] font-semibold text-slate-500">
                    Locked
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
