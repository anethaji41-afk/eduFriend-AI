import React, { useEffect, useState, useRef } from 'react';
import { useEdu } from '../context/EduContext';

export const AnimatedBackground = () => {
  const { visualMode, themeMode, currentPalette, currentVideo } = useEdu();
  const [mousePos, setMousePos] = useState({ x: -500, y: -500 });
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePos({ x: e.clientX, y: e.clientY });
      setIsHovering(true);
    };
    const handleMouseLeave = () => setIsHovering(false);

    window.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseleave', handleMouseLeave);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  const orbs = currentPalette.orbs || [
    'from-purple-600/35 to-indigo-600/25',
    'from-cyan-500/25 via-blue-600/25 to-purple-600/25',
    'from-pink-500/25 to-violet-600/30'
  ];

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none transition-colors duration-700">
      
      {/* 1. Base theme canvas background */}
      {themeMode === 'light' ? (
        <div className="absolute inset-0 bg-slate-50" />
      ) : themeMode === 'lofi' ? (
        <div className="absolute inset-0 bg-[#0d0a1a]" />
      ) : (
        <div className="absolute inset-0 bg-[#040714]" />
      )}

      {/* 2. MODE: VIDEO BACKGROUND */}
      {visualMode === 'video' && (
        <div className="absolute inset-0 transition-opacity duration-1000">
          <video
            key={currentVideo.url}
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover opacity-35 filter blur-[2px]"
          >
            <source src={currentVideo.url} type="video/mp4" />
          </video>
          {/* Overlay dark gradient to preserve text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-slate-950/50" />
        </div>
      )}

      {/* 3. MODE: DYNAMIC ANIMATED GRADIENTS & PARTICLES */}
      {visualMode === 'animated' && (
        <>
          {/* Moving Gradient Orbs */}
          <div
            className={`absolute -top-32 -left-32 w-[600px] h-[600px] rounded-full bg-gradient-to-br ${orbs[0]} blur-[140px] animate-pulse-slow`}
          />
          <div
            className={`absolute top-1/4 -right-28 w-[650px] h-[650px] rounded-full bg-gradient-to-bl ${orbs[1]} blur-[150px] animate-float`}
            style={{ animationDuration: '11s' }}
          />
          <div
            className={`absolute bottom-10 left-1/3 w-[550px] h-[550px] rounded-full bg-gradient-to-tr ${orbs[2]} blur-[130px] animate-float-delayed`}
            style={{ animationDuration: '13s' }}
          />

          {/* Floating Educational Symbols with slow multidirectional movement & soft fade */}
          <div className="absolute inset-0 opacity-[0.20] overflow-hidden">
            {/* Book */}
            <div className="absolute top-[12%] left-[9%] animate-float text-indigo-400 text-3xl">
              📖
            </div>
            {/* Brain */}
            <div className="absolute top-[26%] right-[14%] animate-float-delayed text-cyan-300 text-4xl">
              🧠
            </div>
            {/* Atom */}
            <div className="absolute bottom-[36%] left-[15%] animate-float text-purple-400 text-3xl">
              ⚛️
            </div>
            {/* Lightbulb */}
            <div className="absolute bottom-[22%] right-[20%] animate-float-delayed text-amber-300 text-3xl">
              💡
            </div>
            {/* Graduation Cap */}
            <div className="absolute top-[68%] left-[7%] animate-float text-pink-400 text-4xl">
              🎓
            </div>
            {/* Rocket */}
            <div className="absolute top-[14%] right-[34%] animate-float text-sky-400 text-3xl">
              🚀
            </div>
            {/* Pencil */}
            <div className="absolute top-[48%] left-[45%] animate-float-delayed text-amber-400 text-2xl">
              ✏️
            </div>
            {/* Math Pi */}
            <div className="absolute bottom-[15%] left-[60%] animate-float text-violet-400 text-3xl font-serif">
              π
            </div>
            {/* Sigma */}
            <div className="absolute top-[80%] right-[8%] animate-float-delayed text-emerald-400 text-2xl font-serif">
              Σ
            </div>
          </div>
        </>
      )}

      {/* 4. MODE: MINIMAL / FOCUS MODE */}
      {visualMode === 'minimal' && (
        <div className="absolute inset-0">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-purple-950/20 rounded-full blur-[140px]" />
        </div>
      )}

      {/* 5. MOUSE-FOLLOWING DYNAMIC GLOW LIGHTING EFFECT */}
      {isHovering && (
        <div
          className="absolute w-[450px] h-[450px] rounded-full pointer-events-none transition-transform duration-75 ease-out"
          style={{
            transform: `translate(${mousePos.x - 225}px, ${mousePos.y - 225}px)`,
            background: `radial-gradient(circle, ${currentPalette.glow} 0%, rgba(56, 189, 248, 0.12) 40%, transparent 70%)`,
            filter: 'blur(30px)'
          }}
        />
      )}

      {/* Subtle grid texture overlay */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(#ffffff 1px, transparent 1px), linear-gradient(to right, #ffffff 1px, transparent 1px)`,
          backgroundSize: '48px 48px'
        }}
      />
    </div>
  );
};
