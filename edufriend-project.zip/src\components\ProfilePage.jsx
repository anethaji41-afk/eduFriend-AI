import React, { useState } from 'react';
import { 
  User, 
  Mail, 
  Key, 
  Flame, 
  Award, 
  Clock, 
  Check, 
  Save, 
  ShieldCheck,
  Target
} from 'lucide-react';
import { useEdu } from '../context/EduContext';

export const ProfilePage = () => {
  const { user, updateUser, apiKey, saveApiKey, goals, quizzes } = useEdu();
  const [name, setName] = useState(user?.name || 'Nethaji');
  const [email, setEmail] = useState(user?.email || 'nethaji@edufriend.ai');
  const [dailyGoalMinutes, setDailyGoalMinutes] = useState(user?.dailyGoalMinutes || 60);
  const [avatar, setAvatar] = useState(user?.avatar || '👨‍🎓');
  const [keyInput, setKeyInput] = useState(apiKey || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const avatars = ['👨‍🎓', '👩‍🎓', '🧠', '🚀', '⚡', '🦉', '💻', '💡'];

  const handleSaveProfile = (e) => {
    e.preventDefault();
    updateUser({
      name,
      email,
      dailyGoalMinutes: Number(dailyGoalMinutes),
      avatar
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleSaveKey = (e) => {
    e.preventDefault();
    saveApiKey(keyInput.trim());
  };

  const completedGoals = goals.filter(g => g.completed).length;
  const bestQuizScore = quizzes.length > 0 
    ? Math.max(...quizzes.map(q => q.percentage || 0)) 
    : 0;

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300">
      {/* Profile Header Banner */}
      <div className="glass-panel p-8 rounded-3xl border border-white/10 relative overflow-hidden shadow-2xl">
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <div className="relative group">
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-400 p-[2px] shadow-xl shadow-purple-600/30">
              <div className="w-full h-full bg-slate-950 rounded-[22px] flex items-center justify-center text-5xl">
                {avatar}
              </div>
            </div>
          </div>

          <div className="text-center sm:text-left space-y-1">
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <h2 className="text-2xl sm:text-3xl font-black text-white">{name}</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-semibold">
                Scholar
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 flex items-center justify-center sm:justify-start gap-1.5">
              <Mail className="w-3.5 h-3.5" />
              <span>{email}</span>
            </p>
          </div>
        </div>

        {/* Quick Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 pt-6 border-t border-white/5 text-center">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Study Time</span>
            <span className="text-base font-extrabold text-white">
              {Math.round((user?.totalStudyMinutes || 480) / 60)} hrs
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Streak</span>
            <span className="text-base font-extrabold text-amber-400">
              {user?.streak || 7} Days 🔥
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Best Quiz</span>
            <span className="text-base font-extrabold text-emerald-400">
              {bestQuizScore}%
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Goals Done</span>
            <span className="text-base font-extrabold text-cyan-400">
              {completedGoals}
            </span>
          </div>
        </div>
      </div>

      {/* Edit Profile Form */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 space-y-6">
        <h3 className="text-lg font-bold text-white">Student Details & Preferences</h3>

        <form onSubmit={handleSaveProfile} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">Choose Avatar</label>
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
              {avatars.map((av) => (
                <button
                  key={av}
                  type="button"
                  onClick={() => setAvatar(av)}
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl border transition-all ${
                    avatar === av
                      ? 'bg-purple-600/30 border-purple-500 scale-105 shadow-md shadow-purple-500/25'
                      : 'bg-slate-900 border-white/10 hover:border-purple-500/30'
                  }`}
                >
                  {av}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-950/70 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950/70 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Daily Study Target (Minutes)
            </label>
            <input
              type="number"
              min="15"
              max="360"
              value={dailyGoalMinutes}
              onChange={(e) => setDailyGoalMinutes(e.target.value)}
              className="w-full max-w-xs bg-slate-950/70 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs shadow-lg shadow-purple-600/30 hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>Save Profile</span>
            </button>
          </div>
        </form>
      </div>

      {/* AI Settings / OpenAI API Key Configuration */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/20 space-y-4">
        <div className="flex items-center gap-2">
          <Key className="w-5 h-5 text-purple-400" />
          <h3 className="text-lg font-bold text-white">AI Engine Configuration</h3>
        </div>
        <p className="text-xs text-slate-400">
          EduFriend uses a built-in intelligent extractor by default. To use your personal OpenAI GPT model for quiz generation, paste your API key below. The key is stored safely in your browser only.
        </p>

        <form onSubmit={handleSaveKey} className="flex flex-col sm:flex-row gap-3 pt-2">
          <input
            type="password"
            placeholder="sk-..."
            value={keyInput}
            onChange={(e) => setKeyInput(e.target.value)}
            className="flex-1 bg-slate-950/70 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500 font-mono text-xs"
          />
          <button
            type="submit"
            className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md transition-all shrink-0"
          >
            Save API Key
          </button>
        </form>
      </div>
    </div>
  );
};
