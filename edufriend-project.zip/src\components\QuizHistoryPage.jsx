import React, { useState } from 'react';
import { 
  History, 
  HelpCircle, 
  Trophy, 
  Calendar, 
  Eye, 
  ArrowRight,
  Filter,
  CheckCircle2,
  X
} from 'lucide-react';
import { useEdu } from '../context/EduContext';

export const QuizHistoryPage = () => {
  const { quizzes } = useEdu();
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [filterSubject, setFilterSubject] = useState('All');

  const subjects = ['All', 'Machine Learning', 'Data Structures', 'Python', 'Web Development'];

  const filteredQuizzes = quizzes.filter((q) => {
    if (filterSubject === 'All') return true;
    return q.subject === filterSubject;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
            <History className="w-6 h-6 text-purple-400" />
            <span>Quiz History & Records</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Review past test performance, inspect questions, and identify areas to revise.
          </p>
        </div>

        {/* Filter */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {subjects.map((subj) => (
            <button
              key={subj}
              onClick={() => setFilterSubject(subj)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                filterSubject === subj
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                  : 'bg-slate-800/70 text-slate-400 hover:text-slate-200'
              }`}
            >
              {subj}
            </button>
          ))}
        </div>
      </div>

      {/* Quiz History Table / Cards */}
      {filteredQuizzes.length === 0 ? (
        <div className="glass-panel p-12 rounded-3xl text-center border border-white/10 text-slate-400">
          <HelpCircle className="w-12 h-12 mx-auto text-purple-400/30 mb-3" />
          <p className="text-base font-semibold text-slate-300">No quiz records found</p>
          <p className="text-xs text-slate-500 mt-1">Take a quiz from your notes to build your record!</p>
        </div>
      ) : (
        <div className="glass-panel rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/10 bg-slate-900/60 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  <th className="p-4 sm:px-6">Quiz Title</th>
                  <th className="p-4">Subject</th>
                  <th className="p-4">Difficulty</th>
                  <th className="p-4">Score</th>
                  <th className="p-4">Percentage</th>
                  <th className="p-4">Date</th>
                  <th className="p-4 text-right sm:pr-6">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-sm">
                {filteredQuizzes.map((q) => (
                  <tr key={q.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-4 sm:px-6 font-semibold text-slate-200">
                      {q.title}
                    </td>
                    <td className="p-4">
                      <span className="px-2.5 py-0.5 rounded-md bg-purple-500/10 text-purple-300 border border-purple-500/20 text-xs">
                        {q.subject}
                      </span>
                    </td>
                    <td className="p-4 text-xs text-slate-400">
                      {q.difficulty || 'Medium'}
                    </td>
                    <td className="p-4 font-bold text-white">
                      {q.score} / {q.questionCount}
                    </td>
                    <td className="p-4">
                      <span
                        className={`inline-flex items-center gap-1 font-extrabold text-xs px-2.5 py-1 rounded-full ${
                          q.percentage >= 70
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}
                      >
                        {q.percentage}%
                      </span>
                    </td>
                    <td className="p-4 text-xs text-slate-400 whitespace-nowrap">
                      {q.date || new Date(q.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-4 text-right sm:pr-6">
                      <button
                        onClick={() => setSelectedQuiz(q)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-purple-300 text-xs font-bold border border-white/5 hover:border-purple-500/30 transition-all"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Review</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Review Modal */}
      {selectedQuiz && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
          <div className="relative w-full max-w-2xl max-h-[85vh] flex flex-col glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/30 shadow-2xl bg-slate-900/95">
            <button
              onClick={() => setSelectedQuiz(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-4">
              <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-md bg-purple-500/10 text-purple-300 border border-purple-500/20">
                {selectedQuiz.subject}
              </span>
              <h3 className="text-xl font-bold text-white mt-1">{selectedQuiz.title}</h3>
              <p className="text-xs text-slate-400">
                Completed on {selectedQuiz.date} • Score: {selectedQuiz.score}/{selectedQuiz.questionCount} ({selectedQuiz.percentage}%)
              </p>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4 pr-1">
              {selectedQuiz.questions && selectedQuiz.questions.length > 0 ? (
                selectedQuiz.questions.map((q, idx) => {
                  const isCorrect = q.selectedAnswer === q.answer;
                  return (
                    <div
                      key={idx}
                      className={`p-4 rounded-2xl border ${
                        isCorrect
                          ? 'bg-emerald-950/20 border-emerald-500/30'
                          : 'bg-rose-950/20 border-rose-500/30'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-xs font-bold text-slate-400">Question {idx + 1}</span>
                        <span className={`text-xs font-bold ${isCorrect ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {isCorrect ? '✓ Correct' : '✕ Incorrect'}
                        </span>
                      </div>
                      <p className="text-sm font-semibold text-slate-200 mb-2">{q.question}</p>
                      <div className="text-xs space-y-1">
                        <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-300">
                          <span className="font-bold mr-1">Correct Answer:</span> {q.answer}
                        </div>
                        {!isCorrect && (
                          <div className="p-2 rounded-lg bg-rose-500/10 text-rose-300">
                            <span className="font-bold mr-1">Your Answer:</span> {q.selectedAnswer || 'Not answered'}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              ) : (
                <p className="text-sm text-slate-400">Detailed question log not available for this record.</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
