import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  CheckCircle, 
  Volume2, 
  VolumeX, 
  Sparkles,
  Flame,
  Award
} from 'lucide-react';
import { useEdu } from '../context/EduContext';
import confetti from 'canvas-confetti';

export const StudyTimer = ({ onSessionCompleted }) => {
  const { recordStudySession, user } = useEdu();
  const [selectedMinutes, setSelectedMinutes] = useState(25);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [subject, setSubject] = useState('Machine Learning');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Play subtle synthesized audio beep
  const playSound = (freq = 600, duration = 0.2) => {
    if (!soundEnabled) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // Audio context may be restricted before gesture
    }
  };

  useEffect(() => {
    let interval = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      // Session finished
      playSound(880, 0.6);
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
      recordStudySession(selectedMinutes, subject);
      if (onSessionCompleted) onSessionCompleted(selectedMinutes, subject);
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft]);

  const handleSetPreset = (mins) => {
    setIsRunning(false);
    setSelectedMinutes(mins);
    setTimeLeft(mins * 60);
    playSound(440, 0.1);
  };

  const handleToggle = () => {
    setIsRunning(!isRunning);
    playSound(isRunning ? 350 : 650, 0.15);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(selectedMinutes * 60);
    playSound(300, 0.15);
  };

  const handleManualLog = () => {
    const minutesCompleted = Math.max(1, Math.round((selectedMinutes * 60 - timeLeft) / 60));
    if (minutesCompleted < 1) return;
    setIsRunning(false);
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 }
    });
    recordStudySession(minutesCompleted, subject);
    setTimeLeft(selectedMinutes * 60);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const progressPercent = ((selectedMinutes * 60 - timeLeft) / (selectedMinutes * 60)) * 100;

  return (
    <div className="glass-panel p-6 sm:p-8 rounded-3xl relative overflow-hidden border border-purple-500/20 shadow-2xl backdrop-blur-xl">
      {/* Background glow orb */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 flex flex-col items-center text-center">
        <div className="flex items-center justify-between w-full mb-6">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </span>
            <span className="text-sm font-semibold tracking-wide text-slate-300">Focus Session</span>
          </div>

          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-700/60 text-slate-400 hover:text-slate-200 transition-colors"
            title={soundEnabled ? 'Mute chimes' : 'Enable chimes'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-rose-400" />}
          </button>
        </div>

        {/* Subject selector */}
        <div className="mb-6 w-full max-w-xs">
          <label className="block text-xs font-medium text-slate-400 mb-1.5">Focus Subject</label>
          <select
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            disabled={isRunning}
            className="w-full bg-slate-900/80 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-purple-500 transition-colors"
          >
            <option value="Machine Learning">Machine Learning</option>
            <option value="Data Structures">Data Structures</option>
            <option value="Python">Python</option>
            <option value="Web Development">Web Development</option>
            <option value="General Study">General Study</option>
          </select>
        </div>

        {/* Circular Animated Timer Display */}
        <div className="relative w-56 h-56 flex items-center justify-center my-4">
          <svg className="w-full h-full -rotate-90">
            <circle
              cx="112"
              cy="112"
              r="95"
              className="stroke-slate-800/80"
              strokeWidth="10"
              fill="transparent"
            />
            <circle
              cx="112"
              cy="112"
              r="95"
              className="stroke-purple-500 transition-all duration-1000 ease-linear"
              strokeWidth="10"
              strokeDasharray={2 * Math.PI * 95}
              strokeDashoffset={2 * Math.PI * 95 * (1 - progressPercent / 100)}
              strokeLinecap="round"
              fill="transparent"
              style={{
                filter: 'drop-shadow(0 0 12px rgba(168, 85, 247, 0.6))'
              }}
            />
          </svg>

          <div className="absolute flex flex-col items-center justify-center">
            <span className="text-5xl font-black tracking-tight text-white font-mono">
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </span>
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-300 mt-1">
              {isRunning ? 'Studying...' : 'Paused'}
            </span>
          </div>
        </div>

        {/* Preset quick buttons */}
        <div className="flex items-center gap-2 mb-6">
          {[15, 25, 45, 60].map((m) => (
            <button
              key={m}
              onClick={() => handleSetPreset(m)}
              disabled={isRunning}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                selectedMinutes === m
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/25'
                  : 'bg-slate-800/70 text-slate-400 hover:bg-slate-700/80 hover:text-slate-200'
              }`}
            >
              {m}m
            </button>
          ))}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleReset}
            className="p-3 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-white/10 transition-all hover:scale-105 active:scale-95"
            title="Reset Timer"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            onClick={handleToggle}
            className={`px-8 py-3 rounded-2xl font-bold text-sm flex items-center gap-2 transition-all shadow-xl hover:scale-105 active:scale-95 ${
              isRunning
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:from-amber-400 hover:to-orange-400'
                : 'bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white shadow-purple-600/30'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-5 h-5 fill-current" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-current" />
                <span>Start Studying</span>
              </>
            )}
          </button>

          {timeLeft < selectedMinutes * 60 && (
            <button
              onClick={handleManualLog}
              className="p-3 rounded-2xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 transition-all hover:scale-105 active:scale-95"
              title="End & Save Session Now"
            >
              <CheckCircle className="w-5 h-5" />
            </button>
          )}
        </div>

        <p className="text-xs text-slate-400 mt-4">
          Completing a session automatically logs your study minutes & extends your daily streak!
        </p>
      </div>
    </div>
  );
};
