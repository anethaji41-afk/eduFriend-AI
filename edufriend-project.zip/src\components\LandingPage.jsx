import React from 'react';
import { 
  Sparkles, 
  Target, 
  Timer, 
  BookText, 
  HelpCircle, 
  Flame, 
  ArrowRight, 
  Video,
  Layers,
  Palette
} from 'lucide-react';
import { useEdu } from '../context/EduContext';

export const LandingPage = ({ onGetStarted, onLogin }) => {
  const { currentPalette, changeVisualMode, visualMode } = useEdu();

  // Helper for interactive letter-by-letter hover animation
  const renderInteractiveText = (text) => {
    return text.split('').map((char, index) => (
      <span
        key={index}
        className="interactive-letter"
        style={{ animationDelay: `${index * 0.05}s` }}
      >
        {char === ' ' ? '\u00A0' : char}
      </span>
    ));
  };

  return (
    <div className="space-y-24 py-8 sm:py-16">
      
      {/* Hero Section with Interactive Typography */}
      <section className="text-center max-w-4xl mx-auto space-y-6 px-4">
        
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-semibold animate-pulse-slow">
          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          <span>Next-Gen AI Daily Study Companion • 3 Visual Modes</span>
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight text-white leading-tight">
          {renderInteractiveText('Study Smarter.')} <br />
          <span className="gradient-text-hero">
            {renderInteractiveText('Stay Motivated.')}
          </span>{' '}
          {renderInteractiveText('Learn Better.')}
        </h1>

        <p className="text-slate-300 text-base sm:text-xl font-normal max-w-2xl mx-auto leading-relaxed">
          EduFriend is your friendly AI-powered study companion that helps you plan your study goals, create quizzes from your notes, and maintain study streaks with dynamic ambient backgrounds.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <button
            onClick={onGetStarted}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 text-white font-extrabold text-sm shadow-xl shadow-purple-600/30 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 animate-gradient-shift"
          >
            <span>Get Started Free</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onLogin}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-slate-900/80 hover:bg-slate-800 text-slate-200 font-bold text-sm border border-white/10 hover:border-purple-500/30 transition-all"
          >
            Log In to Demo Account
          </button>
        </div>

        {/* Visual Mode Showcase Pills */}
        <div className="pt-8 flex flex-wrap items-center justify-center gap-3">
          <span className="text-xs text-slate-400 font-medium mr-2">Try Visual Mode:</span>
          {[
            { id: 'animated', label: 'Dynamic Gradients & Particles', icon: Sparkles },
            { id: 'video', label: 'Study Video Ambient', icon: Video },
            { id: 'minimal', label: 'Deep Focus Mode', icon: Layers }
          ].map((m) => {
            const Icon = m.icon;
            return (
              <button
                key={m.id}
                onClick={() => changeVisualMode(m.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  visualMode === m.id
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30 scale-105'
                    : 'bg-slate-900/70 text-slate-400 hover:text-white border border-white/10'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{m.label}</span>
              </button>
            );
          })}
        </div>

        {/* Feature Highlights Banner */}
        <div className="pt-10 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          <div className="p-4 rounded-2xl glass-panel border border-white/5 hover:border-purple-500/30 transition-all hover:scale-105">
            <div className="text-2xl mb-1">🎯</div>
            <div className="text-sm font-bold text-white">Daily Goals</div>
            <div className="text-[11px] text-slate-400">Targeted study time</div>
          </div>
          <div className="p-4 rounded-2xl glass-panel border border-white/5 hover:border-cyan-500/30 transition-all hover:scale-105">
            <div className="text-2xl mb-1">⏱️</div>
            <div className="text-sm font-bold text-white">Focus Timer</div>
            <div className="text-[11px] text-slate-400">Pomodoro logging</div>
          </div>
          <div className="p-4 rounded-2xl glass-panel border border-white/5 hover:border-pink-500/30 transition-all hover:scale-105">
            <div className="text-2xl mb-1">🤖</div>
            <div className="text-sm font-bold text-white">AI Note Quizzes</div>
            <div className="text-[11px] text-slate-400">Strictly from your notes</div>
          </div>
          <div className="p-4 rounded-2xl glass-panel border border-white/5 hover:border-amber-500/30 transition-all hover:scale-105">
            <div className="text-2xl mb-1">🔥</div>
            <div className="text-sm font-bold text-white">Study Streaks</div>
            <div className="text-[11px] text-slate-400">Habit calendar tracking</div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="max-w-6xl mx-auto px-4 space-y-12">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-extrabold text-white">How EduFriend Works</h2>
          <p className="text-sm text-slate-400">Four simple steps to transform your college study sessions</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            {
              step: '01',
              title: 'Set Your Targets',
              desc: 'Define subjects, focus minutes, and daily milestones with priority tags.'
            },
            {
              step: '02',
              title: 'Study & Time',
              desc: 'Run the built-in focus timer with gentle audio ticks to record your actual study minutes.'
            },
            {
              step: '03',
              title: 'Take Notes',
              desc: 'Write or paste lecture summaries, definitions, and formulas into your digital notebook.'
            },
            {
              step: '04',
              title: 'Generate AI Quiz',
              desc: 'Click "Generate Quiz" to test yourself immediately with AI questions made strictly from your notes.'
            }
          ].map((item, idx) => (
            <div key={idx} className="glass-panel p-6 rounded-3xl border border-white/10 relative hover:border-purple-500/30 transition-all hover:-translate-y-1">
              <span className="text-3xl font-black text-purple-400/30 block mb-2">{item.step}</span>
              <h3 className="text-base font-bold text-white mb-2">{item.title}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
